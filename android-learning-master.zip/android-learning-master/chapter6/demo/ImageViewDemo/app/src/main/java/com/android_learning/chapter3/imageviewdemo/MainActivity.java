package com.android_learning.chapter3.imageviewdemo;

import android.app.Activity;
import android.os.Bundle;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_main);
//        setContentView(R.layout.activity_main_demo1);
//        setContentView(R.layout.activity_main_demo2);
        setContentView(R.layout.activity_main_demo3);
        //setContentView(R.layout.activity_main_demo4);
        //setContentView(R.layout.activity_main_demo5);
    }
}
