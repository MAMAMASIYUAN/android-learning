package com.android_learning.chapter3.layoutdemo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_main);

        setContentView(R.layout.activity_main_demo1);
//        setContentView(R.layout.activity_main_demo2);
//        setContentView(R.layout.activity_main_demo3);
//        setContentView(R.layout.activity_main_demo4);
//        setContentView(R.layout.activity_main_demo5);
//        setContentView(R.layout.activity_main_demo6);
        //setContentView(R.layout.activity_main_demo7);
        //setContentView(R.layout.activity_main_demo8);
    }
}
